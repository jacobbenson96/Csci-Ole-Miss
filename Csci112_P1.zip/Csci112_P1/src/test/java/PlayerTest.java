import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PlayerTest {
    @Test
    void emptyConstructor(){
        Player player = new Player();
        assertNotNull(player);
    }

    @Test
    void nonEmptyConstructorName(){
        Player player = new Player("Larry Bird","",0,0,0,0,0,0);
        assertEquals("Larry Bird", player.getName());
    }
    @Test
    void nonEmptyConstructorPosition(){
        Player player = new Player("","Small Forward",0,0,0,0,0,0);
        assertEquals("Small Forward", player.getPosition());
    }
    @Test
    void nonEmptyConstructorFgattempt(){
        Player player = new Player("","",20,0,0,0,0,0);
        assertEquals(20, player.getFgattempt());
    }
    @Test
    void nonEmptyConstructorFgmade(){
        Player player = new Player("","",0,10,0,0,0,0);
        assertEquals(10, player.getFgmade());
    }
    @Test
    void nonEmptyConstructorFtattempt(){
        Player player = new Player("","",0,0,6,0,0,0);
        assertEquals(6, player.getFtattempt());
    }
    @Test
    void nonEmptyConstructorFtmade(){
        Player player = new Player("","",0,0,0,5,0,0);
        assertEquals(5, player.getFtmade());
    }
    @Test
    void nonEmptyConstructorFgprecentage(){
        Player player = new Player("","",0,0,0,0,0,0);
        assertEquals(0, player.getFgprecentage());
    }
    @Test
    void nonEmptyConstructorFtprecentage(){
        Player player = new Player("","",0,0,0,0,0,0);
        assertEquals(0, player.getFtprecentage());
    }

    @Test
    void getName() {
        Player player = new Player();
        player.setName("Larry Bird");
        assertTrue(player.getName()=="Larry Bird");

    }

    @Test
    void getPosition() {
        Player player = new Player();
        player.setPosition("Small Forward");
        assertTrue(player.getPosition()=="Small Forward");
    }

    @Test
    void getFgattempt() {
        Player player = new Player();
        player.setFgattempt(20);
        assertTrue(player.getFgattempt()==20);
    }

    @Test
    void getFgmade() {
        Player player = new Player();
        player.setFgmade(10);
        assertTrue(player.getFgmade()==10);
    }

    @Test
    void getFtattempt() {
        Player player = new Player();
        player.setFtattempt(6);
        assertTrue(player.getFtattempt()==6);
    }

    @Test
    void getFtmade() {
        Player player = new Player();
        player.setFtmade(5);
        assertTrue(player.getFtmade()==5);
    }

    @Test
    void getFgprecentage() {
        Player player = new Player();
        player.setFgprecentage(0);
        assertTrue(player.getFgprecentage()==0);
    }

    @Test
    void getFtprecentage() {
        Player player = new Player();
        player.setFtprecentage(0);
        assertTrue(player.getFtprecentage()==0);
    }

    @Test
    void setName() {
        Player player = new Player();
        player.setName("Larry Bird");
        assertEquals("Larry Bird",player.getName());
    }

    @Test
    void setPosition() {
        Player player = new Player();
        player.setPosition("Small Forward");
        assertEquals("Small Forward",player.getPosition());
    }

    @Test
    void setFgattempt() {
        Player player = new Player();
        player.setFgattempt(20);
        assertEquals(20,player.getFgattempt());
    }

    @Test
    void setFgmade() {
        Player player = new Player();
        player.setFgmade(10);
        assertEquals(10,player.getFgmade());
    }

    @Test
    void setFtattempt() {
        Player player = new Player();
        player.setFtattempt(6);
        assertEquals(6,player.getFtattempt());
    }

    @Test
    void setFtmade() {
        Player player = new Player();
        player.setFtmade(5);
        assertEquals(5,player.getFtmade());
    }

    @Test
    void setFgprecentage() {
        Player player = new Player();
        player.setFgprecentage(0);
        assertEquals(0,player.getFgprecentage());
    }

    @Test
    void setFtprecentage() {
        Player player = new Player();
        player.setFtprecentage(0);
        assertEquals(0,player.getFtprecentage());
    }
}

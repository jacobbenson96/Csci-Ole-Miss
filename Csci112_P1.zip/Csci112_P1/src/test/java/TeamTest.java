import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TeamTest {

    @Test
    void getTeamname() {
    }

    @Test
    void setTeamname() {
    }

    @Test
    void addPlayer() {
    }
}
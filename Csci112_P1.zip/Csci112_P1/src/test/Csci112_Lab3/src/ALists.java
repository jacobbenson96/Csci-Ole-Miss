import java.util.ArrayList;
import java.util.Random;

public class ALists {
    private static Random rand = new Random();
    private ArrayList<Integer> numbers = new ArrayList<Integer>();
    private ArrayList<String> strings = new ArrayList<String>();
public void times (int var){
    for(int i=0; i<var; i++){
        int num = rand.nextInt(61) + 35;
        numbers.add(num);
    }
    System.out.println("There are " +numbers.size()+ " numbers in the arrayList!");
}
public void loopandprint (){
    //System.out.println("The values in the arraylist:");
    for(int i = 0; i< numbers.size(); i++){
        System.out.println(numbers.get(i));
    }
}
public void change (){
    numbers.remove(12);
    numbers.remove(9);
    numbers.remove(5);
    numbers.remove(3);
    numbers.add(6,70);
    numbers.set(2,99);
    System.out.println(numbers.size());

}
public void enhancedFor (){
    for(Integer num: numbers){
        System.out.println(num);
    }
}
public void astring (String s){
    strings.add(new String());
}
public void iterate(){
    for(String num: strings){
        System.out.println(num);
    }
}
public void combo (int a, String b){

}

}

public class Driver {
    public static void main(String[] args) {
        ALists alist = new ALists();
        alist.times(15);
        alist.loopandprint();
        alist.change();
        alist.enhancedFor();
        alist.astring("The");
        alist.astring("Time");
        alist.astring("and");
        alist.astring("waits");
        alist.astring("for");
        alist.astring("no");
        alist.astring("one");
        alist.iterate();







    }
}

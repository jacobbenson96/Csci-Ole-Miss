import java.util.Arrays;

public class Team {
    private String teamname;
    private Player[] members;
    private int index;

    public Team() {
        teamname = "";
        members = new Player[15];
        index = 0;

    }

    public Team(String Teamname) {
        teamname = Teamname;
        members = new Player[15];
        index = 0;

    }

    public String getTeamname(String Teamname) {
        return teamname;

    }

    public void setTeamname(String Teamname) {
        teamname = Teamname;
    }

    public void addPlayer(String Name, String Position, int fga, int fgm, int fta, int ftm, float fgp, float ftp) {
        Player a = new Player(Name, Position, fga, fgm, fta, ftm, fgp, ftp);
        members[index] = a;
        // members[index]=new Player(Name,Position, fga,fgm,fta,ftm,fgp,ftp);
        index++;

    }

    public void Printmethod() {
        System.out.println("Boston Celtics 1986-87 Season!");
        System.out.println();
        System.out.println("Starting Line Up Season Stats:");
        for (int i = 0; i < members.length; i++) {
            System.out.println(members[i].getName() + members[i].getPosition() + members[i].getFgattempt() + members[i].getFgmade() + members[i].getFtattempt() + members[i].getFtmade());
            //System.out.println(Arrays.toString(members));
        }


    }
}




public class Player {
    private String name;
    private String position;
    private int fgattempt;
    private int fgmade;
    private int ftattempt;
    private int ftmade;
    public float fgprecentage;
    public float ftprecentage;

    public Player(){
        name = "";
        position = "";
        fgattempt = 0;
        fgmade = 0;
        ftattempt= 0;
        ftmade= 0;
        fgprecentage=0;
        ftprecentage=0;

    }
    public Player(String Name, String Position, int fga, int fgm, int fta, int ftm, float fgp, float ftp){
        name = Name;
        position=Position;
        fgattempt=fga;
        fgmade=fgm;
        ftattempt=fta;
        ftmade=ftm;
        fgprecentage=fgp;
        ftprecentage=ftp;
    }

    public String getName(){
        return name;
    }
    public String getPosition(){
        return position;
    }
    public int getFgattempt(){
        return fgattempt;
    }
    public int getFgmade(){
        return fgmade;
    }
    public int getFtattempt(){
        return ftattempt;

    }
    public int getFtmade(){
        return ftmade;

    }
    public float getFgprecentage(){
       // fgprecentage1 = (fgmade/fgattempt)*100;
        return fgprecentage;

    }
    public float getFtprecentage(){
        //ftprecentage = (ftmade/ftattempt)*100;
        return ftprecentage;

    }
    public void setName (String Name){
        name = Name;
    }
    public void setPosition (String Position){
        position = Position;
    }
    public void setFgattempt(int fga){
        fgattempt = fga;
    }
    public void setFgmade(int fgm){
        fgmade = fgm;
    }
    public void setFtattempt(int fta){
        ftattempt = fta;
    }
    public void setFtmade(int ftm){
        ftmade = ftm;
    }
    public void setFgprecentage(float fgp){
        fgprecentage = fgp;
    }
    public void setFtprecentage(float ftp){
        ftprecentage = ftp;
    }
    public void calcftp(){
        ftprecentage = (float)(ftmade/ftattempt)*100;
    }
    public void calcfgp(){
        fgprecentage = (float)(fgmade/fgattempt)*100;
    }
}

public class DriverP1 {
    public static void main(String[] args) {
        Team team = new Team("Boston Celtics");
        //Player player = new Player();
        team.addPlayer("Danny Ainge","Shooting Guard", 12,6,2,2,0,0);
        team.addPlayer("Larry Bird","Small Forward", 20,10,6,5,0,0);
        team.addPlayer("Dennis Johnson","Point Guard", 12,5,3,2,0,0);
        team.addPlayer("Greg Kite","Center", 1,0,1,0,0,0);
        team.addPlayer("Fred Roberts","Power Forward", 3,2,2,1,0,0);
        team.Printmethod();









    }
}
